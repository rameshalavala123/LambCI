# gilded-rose kata

This project is meant to be used to work on the [Gilded Rose
kata](https://github.com/testdouble/contributing-tests/wiki/Gilded-Rose-Kata). It
comes pre-configured with JUnit, Hamcrest, and Mockito.

```
.
├── README.md
├── pom.xml
├── src
│   ├── main
│   │   └── java
│   │       └── gildedrose
│   │           ├── GildedRose.java
│   │           └── Item.java
```


