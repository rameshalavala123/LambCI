package bank;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(plugin = { "pretty" }, monochrome = true)
public class RunCukesTest {

	// This test is intentionally blank

	// See:
	// * src/test/resources for Gherkin Feature files
	// * bank.Stepdefs for step definitions

}
