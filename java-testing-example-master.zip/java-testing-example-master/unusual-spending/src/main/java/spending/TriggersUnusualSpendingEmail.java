package spending;

public class TriggersUnusualSpendingEmail {

	public void trigger(long userId) {
		// TODO: This is the entry point. Start with a test of this class
	}

}
