# greeting kata

This project is meant to be used to work on the [Greeting
kata](https://github.com/testdouble/contributing-tests/wiki/Greeting-Kata). It
comes pre-configured with JUnit, Hamcrest, and Mockito.
