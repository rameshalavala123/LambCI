package example.values;

public class WalrusFood {

}
