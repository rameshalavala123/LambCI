package spending;

public class EmailsUser {

	public static void email(long userId, String subject, String body) {
		throw new RuntimeException("Email will be implemented by a different team later");
	}

}
